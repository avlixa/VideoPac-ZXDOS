This are the postscript files for a Videopac / Odyssey^2 cartridge. It
supports 4 banks of 3K each with a 27c128 or 2 banks of 3K each with a
27c64. The EPROM is mapped 1:1 with all address lines, so there has to be
put dummy data into the first 1K of every bank, this space is unavailable
due to the BIOS.  This leads to the following EPROM memory map:

0000h-03ffh Unavailable due to BIOS
0400h-0fffh Bank 0
1000h-13ffh Unavailable due to BIOS
1400h-1fffh Bank 1
2000h-23ffh Unavailable due to BIOS
2400h-2fffh Bank 2
3000h-33ffh Unavailable due to BIOS
3400h-3fffh Bank 3

For a 27c64 the banks 0 and 2 are identical, the same is true for banks 1
and 3.

Using this design for 2K per bank is possible, but is a waste of space.

There is more information about this and other PCBs at my home page at
<http://soeren.informationstheater.de/g7000/cart.html>.

This files are for home brew PCB production. They are double sided, but are
very simple, there is just the Videopac slot, the EPROM and 1 jumper wire.
So if you have already etched single sided PCBs before this should be
doable. Even if you have never etched a PCB before it is still manageable,
although I recommend trying something single sides before. As this is
double sided you need to solder the parts on the top side, too.

The PCB should fit into a standard Videopac case, but there is one thing
to watch out for: If you use a Ceramic UV Erasable EPROM you need low
profile carrier type sockets, otherwise the case won't close completely.
The holes are 1mm big, because carrier type sockets require bigger holes
than normal sockets. OTP EPROMs fit even with normal sockets.

The connection between ground and pin B on the cart slot has a thin part,
this is for easier cutting. Pin B needs to be left open for some features
of the Videopac. Cutting through the thin part enables "The Voice" and
allows to use box mode on the Videopac+ to blank VDC graphics.

Don't forget the jumper wire.

You need to drill 2 5mm holes for the case screws.

The contents of the postscript files:

component.eps	Top copper layer
solder.eps	Bottom copper layer
outline.eps	Outline, milling data
silk.eps	Top silk screen
mask.eps	Solder mask top/bottom
